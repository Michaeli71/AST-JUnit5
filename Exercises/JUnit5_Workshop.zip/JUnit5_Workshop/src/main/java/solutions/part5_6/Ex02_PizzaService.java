package solutions.part5_6;

import exercises.part5_6.SmsNotificationService;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex02_PizzaService
{
    private final SmsNotificationService notificationService;

    public Ex02_PizzaService()
    {
        notificationService = getNotificationService();
    }

    public void orderPizza(final String name)
    {
        notificationService.notify("Pizza " + name + " wird in Kürze geliefert.");
    }

    protected SmsNotificationService getNotificationService()
    {
        return new SmsNotificationService();
    }
}
