package solutions.part5_6;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import exercises.part5_6.SmsNotificationService;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class StubNotificationService extends SmsNotificationService
{
    private final List<String> messages = new ArrayList<>();

    public void notify(String msg)
    {
        messages.add(msg);
    }

    public List<String> getMessages()
    {
        return Collections.unmodifiableList(messages);
    }
}
