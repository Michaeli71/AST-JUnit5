package solutions.part3;

public class BracesChecker {

	static boolean checkBraces(final String input)
	{
	  int openingCount = 0;
	  for (char ch : input.toCharArray())
	  {
	    if (ch == '(')
	    {
	      openingCount++;
	    }
	    else if (ch == ')')
	    {
	      openingCount--;
	      if (openingCount < 0)
	        return false;
	    }
	  }
	  return openingCount == 0;
	}

}
