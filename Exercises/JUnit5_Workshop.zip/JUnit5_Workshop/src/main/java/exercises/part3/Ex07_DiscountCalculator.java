package exercises.part3;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex07_DiscountCalculator 
{
    // ACHTUNG: Enthält bewusst ein paar kleine Fehler
	public static int calcDiscount(final int count)
	{
		if (count < 50)
			return 0;
		if (count > 50 && count < 1000)
			return 4;
		if (count > 1000)
			return 7;

		throw new IllegalStateException("programming problem: should never " +
	                  "reach this line. value " + count + " is not handled!");
	}
	
	public static void main(String[] args) {
		
		//10, 60, 1050 => all discounts
		System.out.println(calcDiscount(10));
		System.out.println(calcDiscount(60));
		System.out.println(calcDiscount(1050));

		//		 Boundary 50, 1000, also 0 => 49/51 999 / 1001
		// System.out.println(calcDiscount(50));
		// System.out.println(calcDiscount(1000));
		
		//Negative numbers, decimal numbers
		// 		 String and other types, „producing“ error => GOOD IDEA
	}
}