package exercises.part3;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex01_StringUtils
{
    private Ex01_StringUtils()
    {     
    }
    
    public static String reverse(final String original)
    {
        final char[] originalChars = original.toCharArray();

        int left = 0;
        int right = originalChars.length - 1;

        while (left < right)
        {
            final char leftChar = originalChars[left];
            final char rightChar = originalChars[right];

            // swap
            originalChars[left] = rightChar;
            originalChars[right] = leftChar;

            left++;
            right--;
        }

        return String.valueOf(originalChars);
    }
}