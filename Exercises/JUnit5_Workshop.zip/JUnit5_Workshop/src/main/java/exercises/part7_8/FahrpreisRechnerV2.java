package exercises.part7_8;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.MonthDay;
import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class FahrpreisRechnerV2
{
    public static int fahrpreisImproved(int grundpreis, int preisProKM, int streckeInKM, boolean istNachtfahrt,
                                        boolean mitGepäck, boolean amFeiertag)
    {
        int basispreis = preisProKM * streckeInKM;
        int rabatt = berechneRabatt(streckeInKM, basispreis);
        int zuschlag = berechneZuschlag(basispreis, istNachtfahrt, mitGepäck, amFeiertag);

        return grundpreis + basispreis + zuschlag - rabatt;
    }

    private static int berechneRabatt(int streckeInKM, int basispreis)
    {
        int rabatt = 0;
        if (streckeInKM > 50)
            rabatt = (int) (0.1 * basispreis + 0.5);
        else if (streckeInKM > 10)
            rabatt = (int) (0.05 * basispreis + 0.5);
        return rabatt;
    }

    private static int berechneZuschlag(int basispreis, boolean istNachtfahrt, boolean mitGepäck, boolean amFeiertag)
    {
        int zuschlag = 0;
        if (istNachtfahrt)
            zuschlag = (int) (0.2 * basispreis + 0.5);
        if (mitGepäck)
            zuschlag += 3_00;
        if (amFeiertag)
            zuschlag += (int) (0.1 * basispreis + 0.5);
        return zuschlag;
    }

    public static boolean isSunday(LocalDate day)
    {
        return day.getDayOfWeek() == DayOfWeek.SUNDAY;
    }

    public static boolean isFeiertag(LocalDate day)
    {
        final MonthDay currentMonthDay = MonthDay.of(day.getMonth(), day.getDayOfMonth());

        final List<MonthDay> predefinesFeiertage = Arrays.asList(MonthDay.of(1, 1), MonthDay.of(5, 1), MonthDay.of(8, 1),
                                                     MonthDay.of(25, 12), MonthDay.of(26, 12));

        return predefinesFeiertage.contains(currentMonthDay);
    }
}
