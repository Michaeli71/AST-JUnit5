package exercises.part5_6;

import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex06_DateInRomanCharsService 
{ 
   private Arabic2RomanConverter converter;
 
   public String getRomanDate(final LocalDate date) 
   {
	   String day = converter.convert(date.getDayOfMonth());
	   String month = converter.convert(date.getMonthValue());
	   String year = converter.convert(date.getYear());

	  return String.format("%s-%s-%s", day, month, year);
   }
}