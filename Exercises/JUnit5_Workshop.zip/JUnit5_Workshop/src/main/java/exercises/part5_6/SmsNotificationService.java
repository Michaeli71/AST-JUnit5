package exercises.part5_6;

import javax.swing.JOptionPane;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class SmsNotificationService
{
    public void notify(final String msg)
    {
        // SMS versenden ... hier durch einen Dialog repräsentiert
        JOptionPane.showConfirmDialog(null, msg);
    }
}