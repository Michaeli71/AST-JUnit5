package exercises.part5_6;

import java.util.Collections;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class PersonDao
{
    public List<Person> findAll()
    {
        return Collections.emptyList();
    }

    public Person findById(int id)
    {        
        return null;
    }
}
