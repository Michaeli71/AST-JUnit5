package solutions.part5_6;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.AdditionalMatchers;
import org.mockito.Mockito;

import exercises.part5_6.Ex05_PersonService;
import exercises.part5_6.Person;
import exercises.part5_6.PersonDao;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Ex05_PersonServiceTest
{
    private Ex05_PersonService service;
    private PersonDao     dao;

    @BeforeEach
    public void setup()
    {
        dao = Mockito.mock(PersonDao.class);
        service = new Ex05_PersonService(dao);
    }

    @Test
    void testFindById()
    {
        Mockito.when(dao.findById(1)).thenReturn(new Person(1, "Micha", "Inden", 48));

        Person person1 = service.findById(1);
        Person person2 = service.findById(2);

        assertAll(() -> assertNotNull(person1), 
                  () -> assertNull(person2));
    }

    @Test
    void testFindById_ShouldRaiseException_For_NegativeId()
    {
        // Mockito.when(dao.findById(1)).thenReturn(new Person(1, "Micha", "Inden", 48));
        Mockito.when(dao.findById(AdditionalMatchers.lt(0))).thenThrow(IllegalArgumentException.class);
        //Mockito.when(dao.findById(-2)).thenThrow(IllegalArgumentException.class);

        Executable action = () -> service.findById(-2);
        
        assertThrows(IllegalArgumentException.class, 
                     action);
    }

    @Test
    public void testFindAll()
    {
        final List<Person> findAllResults = new ArrayList<>();
        findAllResults.add(new Person(1, "Mike", "Muster", 27));
        findAllResults.add(new Person(2, "Carl", "Käfer", 35));
        findAllResults.add(new Person(3, "Peter", "Peters", 67));

        Mockito.when(dao.findAll()).thenReturn(findAllResults);

        final List<Person> result = service.findAll();
        System.out.println(result);

        assertEquals(3, result.size());

        // verify method call
        Mockito.verify(dao).findAll();
    }

    @Test
    public void testMethodCallTimes()
    {
		// Act
		final Person person11 = service.findById(11);
		if (person11 == null)
		{
		    final List<Person> result = service.findAll();
		    final Person person1 = service.findById(1);
		    final Person person2 = service.findById(2);
		    
		    // final List<Person> result2 = service.findAll();
		}

        // verify method call
        Mockito.verify(dao, Mockito.atLeast(1)).findById(1);
        Mockito.verify(dao, Mockito.atMost(3)).findById(Mockito.anyInt());
        Mockito.verify(dao, Mockito.times(1)).findAll();
    }
}