package solutions.part2;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex03_PersonWithAddressTest
{
    @Test
    void personCreationZurich()
    {
        Ex03_PersonWithAddress michael = Ex03_PersonWithAddress
                        .createZurichLocated("Michael", LocalDate.of(1971, 2, 7));

        assertAll(() -> assertEquals("Michael", michael.name),
                  () -> assertEquals(LocalDate.of(1971, 2, 7), michael.dateOfBirth),
                  () -> assertEquals("Zürich", michael.city), 
                  () -> assertEquals("Switzerland", michael.country));
    }

    @Test
    void personCreationKiel()
    {
        Ex03_PersonWithAddress tim = Ex03_PersonWithAddress.createKielLocated("Tim", LocalDate.of(1971, 3, 27));

        assertAll(() -> assertEquals("Tim", tim.name),
                  () -> assertEquals(LocalDate.of(1971, 3, 27), tim.dateOfBirth),
                  () -> assertEquals("Kiel", tim.city),
                  () -> assertEquals("Germany", tim.country));
    }
}
