package solutions.part7_8;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.function.IntPredicate;

import org.junit.jupiter.api.Test;

import domain.Person;
import exercises.part7_8.Ex01_VersionNumberUtils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex01_VersionNumberComparatorTest
{
    @Test
    void testVersions()
    {
        String v1 = "1.11.17";
        String v2 = "2.3.5";
        String v3 = "2.4";
        String v4 = "3.1"; // 3.5
        String v5 = "3.1.72";

        // assertEquals(0, Ex01_VersionNumberUtils.compareVersions(v1, v1));
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v1, v1) == 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v1, v2) < 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v2, v1) > 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v2, v3) < 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v3, v4) < 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v3, v1) > 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v4, v5) < 0);
        assertTrue(Ex01_VersionNumberUtils.compareVersions(v5, v4) > 0);
    }

    // => Test Smells entfernen

    @Test
    void testVersionsJUnit5_MiniImprovenmet()
    {
        String v1 = "1.11.17";
        String v2 = "2.3.5";
        String v3 = "2.4";
        String v4 = "3.1"; // 3.5
        String v5 = "3.1.72";

        assertAll(() -> assertTrue(Ex01_VersionNumberUtils.compareVersions(v1, v1) == 0),
                  () -> assertTrue(Ex01_VersionNumberUtils.compareVersions(v1, v2) < 0),
                  () -> assertTrue(Ex01_VersionNumberUtils.compareVersions(v2, v1) > 0),
                  () -> assertTrue(Ex01_VersionNumberUtils.compareVersions(v2, v3) < 0),
                  () -> assertTrue(Ex01_VersionNumberUtils.compareVersions(v3, v4) < 0),
                  () -> assertTrue(Ex01_VersionNumberUtils.compareVersions(v3, v1) > 0),
                  () -> assertTrue(Ex01_VersionNumberUtils.compareVersions(v4, v5) < 0),
                  () -> assertTrue(Ex01_VersionNumberUtils.compareVersions(v5, v4) > 0));
    }

    @Test
    void testVersionsUnit5_Java8_Improvenmet_V1()
    {
        String v1 = "1.11.17";
        String v2 = "2.3.5";
        String v3 = "2.4";
        String v4 = "3.1"; // 3.5
        String v5 = "3.1.72";

        IntPredicate IS_SAME = n -> n == 0;
        IntPredicate IS_SMALLER_THAN = n -> n < 0;
        IntPredicate IS_BIGGER_THAN = n -> n > 0;

        assertAll(() -> assertComparator(IS_SAME, Ex01_VersionNumberUtils.compareVersions(v1, v1), v1, v2, "=="),
                  () -> assertComparator(IS_SMALLER_THAN, Ex01_VersionNumberUtils.compareVersions(v1, v2), v1, v2, "<"),
                  () -> assertComparator(IS_BIGGER_THAN, Ex01_VersionNumberUtils.compareVersions(v2, v1), v1, v2, ">"),
                  () -> assertComparator(IS_SMALLER_THAN, Ex01_VersionNumberUtils.compareVersions(v2, v3), v2, v3, "<"),
                  () -> assertComparator(IS_SMALLER_THAN, Ex01_VersionNumberUtils.compareVersions(v3, v4), v3, v4, "<"),
                  () -> assertComparator(IS_BIGGER_THAN, Ex01_VersionNumberUtils.compareVersions(v3, v1), v3, v1, ">"),
                  () -> assertComparator(IS_SMALLER_THAN, Ex01_VersionNumberUtils.compareVersions(v4, v5), v4, v5, "<"),
                  () -> assertComparator(IS_BIGGER_THAN, Ex01_VersionNumberUtils.compareVersions(v5, v4), v5, v4, ">"));
    }

    private void assertComparator(IntPredicate expectedResult, int compareResult, String v1, String v2,
                                  String resultHint)
    {
        assertTrue(expectedResult.test(compareResult),
                   () -> String.format("comparing %1$s with %2$s should result in %1$s %3$s %2$s", v1, v2, resultHint));
    }

    // Schritt 2:
    enum Comparision {
        IS_SAME(n -> n == 0, "="), IS_SMALLER_THAN(n -> n < 0, "<"), IS_BIGGER_THAN(n -> n > 0, ">");

        private IntPredicate comparionsFunction;

        private String       resultHint;

        private Comparision(IntPredicate comparionsFunction, String resultHint)
        {
            this.comparionsFunction = comparionsFunction;
            this.resultHint = resultHint;
        }
    }

    @Test
    void testVersionsJUnit5_Java8_Improvenmet_V2()
    {
        String v1 = "1.11.17";
        String v2 = "2.3.5";
        String v3 = "2.4";
        String v4 = "3.1"; // 3.5
        String v5 = "3.1.72";

        assertAll(() -> assertVersionComparison(v1, Comparision.IS_SAME, v1),
                  () -> assertVersionComparison(v1, Comparision.IS_SMALLER_THAN, v2),
                  () -> assertVersionComparison(v2, Comparision.IS_BIGGER_THAN, v1),
                  () -> assertVersionComparison(v2, Comparision.IS_SMALLER_THAN, v3),
                  () -> assertVersionComparison(v3, Comparision.IS_SMALLER_THAN, v4),
                  () -> assertVersionComparison(v3, Comparision.IS_BIGGER_THAN, v1),
                  () -> assertVersionComparison(v4, Comparision.IS_SMALLER_THAN, v5),
                  () -> assertVersionComparison(v5, Comparision.IS_BIGGER_THAN, v4));
    }

    // Parameterreihenfolge bewusst so, dass Aufrufer noch klarer kommuniziert
    private void assertVersionComparison(String v1, Comparision expectedResult, String v2)
    {
        int compareResult = Ex01_VersionNumberUtils.compareVersions(v1, v2);

        assertComparator(expectedResult.comparionsFunction, compareResult, v1, v2, expectedResult.resultHint);
    }

    @Test
    void testVersions_Improvenmet_AssertJ()
    {
        String v1 = "1.11.17";
        String v2 = "2.3.5";
        String v3 = "2.4";
        String v4 = "3.1"; // 3.5
        String v5 = "3.1.72";

        Ex01_VersionNumberComparator versionNumberComparator = new Ex01_VersionNumberComparator();

        assertAll(() -> assertThat(v1).usingComparator(versionNumberComparator).isEqualTo(v1),
                  () -> assertThat(v1).usingComparator(versionNumberComparator).isLessThan(v2),
                  () -> assertThat(v2).usingComparator(versionNumberComparator).isGreaterThan(v1),
                  () -> assertThat(v2).usingComparator(versionNumberComparator).isLessThan(v3),
                  () -> assertThat(v3).usingComparator(versionNumberComparator).isLessThan(v4),
                  () -> assertThat(v3).usingComparator(versionNumberComparator).isGreaterThan(v1),
                  () -> assertThat(v4).usingComparator(versionNumberComparator).isLessThan(v5),
                  () -> assertThat(v5).usingComparator(versionNumberComparator).isGreaterThan(v4));
    }

    // ------------------------------------------------------------------------------

    @Test
    void assertTrueForever()
    {
        final Person mike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");
        final Person sameMike = mike;
        final Person otherMike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");
              
        // coole Kommentare von SONARLINT !!!!!!!!!!!!!!!
        assertTrue(mike != null, "mike not null");
        assertTrue(mike == sameMike, "same obj");
        assertTrue(mike.equals(otherMike), "same content");
    }

    // => 

    @Test
    void rightAssertsForTheJob()
    {
        final Person mike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");
        final Person sameMike = mike;
        final Person otherMike = new Person("Mike", LocalDate.of(1971, 2, 7), "Zürich");

        assertNotNull(mike, "mike not null");
        assertSame(mike, sameMike, "same obj");
        assertEquals(mike, otherMike, "same content");
    }
}
