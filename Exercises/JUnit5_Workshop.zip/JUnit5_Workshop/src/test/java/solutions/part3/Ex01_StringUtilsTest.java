package solutions.part3;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import exercises.part3.Ex01_StringUtils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex01_StringUtilsTest
{
    @Test
    public void testReverseSingleChars() throws Exception
    {
        String input = "A";
        
        assertEquals("A", Ex01_StringUtils.reverse(input));
    }
    
    @Test
    public void testReverseAbcd() throws Exception
    {
        String input = "ABCD";
        
        assertEquals("DCBA", Ex01_StringUtils.reverse(input));
    }

    @Test
    public void testReverseNumbersFrom0_9() throws Exception
    {
        String input = "0123456789";
        
        assertEquals("9876543210", Ex01_StringUtils.reverse(input));
    }
   
    // => JUnit 5 
    
    @ParameterizedTest
    @CsvSource(  {"A,A", "ABCD,DCBA", "0123456789,9876543210" } )
    public void testReverseInput(String input, String expected)
    {
        assertEquals(expected, Ex01_StringUtils.reverse(input));
    }
}
