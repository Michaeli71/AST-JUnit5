package solutions.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class CheckBracesTest {
	@ParameterizedTest(name="checkBraces(''{0}'') -- Note: {2}" )
	@CsvSource({ "(()), true, ok",
	             "()(), true, ok",
	             "(()))((()), false, not neatly nested",
	             "((), false, no suitable bracketing",
	             ")(), false, starts with closing parenthesis" })
	void testCheckBraces(String input, boolean expected, String hint)
	{
	    boolean result = BracesChecker.checkBraces(input);
	
	    assertEquals(expected, result);
	}
}