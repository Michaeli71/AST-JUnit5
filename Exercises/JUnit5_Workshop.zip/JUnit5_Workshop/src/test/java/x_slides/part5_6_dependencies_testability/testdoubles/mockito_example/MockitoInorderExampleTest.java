package x_slides.part5_6_dependencies_testability.testdoubles.mockito_example;

import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoInorderExampleTest 
{
@Test
public void testMethodCallsAreInOrder() 
{
	ServiceClassA firstMock = Mockito.mock(ServiceClassA.class);
	ServiceClassB secondMock = Mockito.mock(ServiceClassB.class);

	Mockito.doNothing().when(firstMock).methodOne();
	Mockito.doNothing().when(secondMock).methodTwo();
	Mockito.doNothing().when(firstMock).methodThree();

	// InOrder zeichnet Reihenfolge der Methoden der übergebnen Mocks auf
	InOrder inOrder = Mockito.inOrder(firstMock, secondMock);

	firstMock.methodOne();
	secondMock.methodTwo();
	firstMock.methodThree();
	
	// Prüfe, dass die Aufrufe in der richtigen Reihenfolge erfolgen
	inOrder.verify(firstMock).methodOne();
	inOrder.verify(secondMock).methodTwo();
    inOrder.verify(firstMock).methodThree();
}

	static class ServiceClassA {

		public void methodOne() {
		}

		public void methodThree() {
		}

	}

	static class ServiceClassB {

		public void methodTwo() {
		}
	}
}