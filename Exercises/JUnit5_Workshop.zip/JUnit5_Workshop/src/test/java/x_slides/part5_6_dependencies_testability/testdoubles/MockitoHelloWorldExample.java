package x_slides.part5_6_dependencies_testability.testdoubles;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

public class MockitoHelloWorldExample 
{
	@Test
	void testGreetingReturnValue()
	{
		// Arrange
		final Greeting greeting = mock(Greeting.class);
		when(greeting.greet()).thenReturn("Changed by Mockito");

		// Act
		final String result = greeting.greet();

		// Assert
		assertEquals("Changed by Mockito", result);
	}
}