package x_slides.part5_6_dependencies_testability.testdoubles.mockito_example;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class PizzaService
{
    private final SmsNotificationService notificationService;

    public PizzaService(final SmsNotificationService notificationService)
    {
		this.notificationService = notificationService;
    }
	
    public void orderPizza(final String name)
    {
	    notificationService.send(createNotificationMsg(name));
    }
    
    /* private */ static String createNotificationMsg(final String name) 
    {
	    return "Pizza " + name + " wird in K�rze geliefert.";
    }
}