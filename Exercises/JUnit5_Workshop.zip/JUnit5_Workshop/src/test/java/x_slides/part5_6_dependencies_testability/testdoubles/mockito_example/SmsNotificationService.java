package x_slides.part5_6_dependencies_testability.testdoubles.mockito_example;

import javax.swing.JOptionPane;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class SmsNotificationService 
{
	public void send(final String msg) 
	{
		// SMS versenden ... hier durch einen Dialog repr�sentiert
		JOptionPane.showConfirmDialog(null, msg);
	}
}