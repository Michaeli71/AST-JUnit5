package x_slides.part5_6_dependencies_testability.testdoubles.mockito_example;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoVerifyCallsAndParamsExample 
{
    @Test
    public void testVerifyCallsAndParams() 
    {
        // Arrange
        final Greeting greeting = mock(Greeting.class);
        when(greeting.greet(anyString())).
                      thenReturn("Hello Mockito1", "Hello Mockito2");
    
        // Act
        final Application app = new Application(greeting);
        final String result1 = app.generateMsg("One");
        final String result2 = app.generateMsg("Two");
        final String result3 = app.generateMsg("Three");
    
        // Assert
        verify(greeting).greet("One");
        verify(greeting).greet("Two");
        verify(greeting).greet("Three");
        // Achtung: TooManyActualInvocations => wie gehen wir damit um: times()!
        //verify(greeting).greet(anyString());
    }    
}