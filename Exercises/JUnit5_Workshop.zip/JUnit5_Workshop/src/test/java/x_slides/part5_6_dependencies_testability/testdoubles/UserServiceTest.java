package x_slides.part5_6_dependencies_testability.testdoubles;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

 
/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@ExtendWith(MockitoExtension.class)
public class UserServiceTest 
{ 
   @Mock
   UserManager userManager;
 
   @Test
   public void testSaveArgMatch() throws Exception 
   {
      final String name = "Michael";
      
      final UserService userService = new UserService(userManager);
      userService.save(name);
      
      Mockito.verify(userManager, Mockito.times(1)).save(Mockito.anyString());
      Mockito.verify(userManager, Mockito.times(1)).save(Mockito.isA(String.class));
      Mockito.verify(userManager, Mockito.times(1)).save(Mockito.startsWith("Mi"));
      Mockito.verify(userManager, Mockito.times(1)).save(Mockito.endsWith("l"));
   }
}