package x_slides.part5_6_dependencies_testability.testdoubles;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class UserService 
{
	UserManager userManager;
	
	public UserService(UserManager userManager) {
		this.userManager = userManager;
	}

	public void save(String name) {
		userManager.save(name);
	}

}