package x_slides.part5_6_dependencies_testability.testdoubles;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public final class SimulationDisplayStubAdvanced implements IDisplay
{
    private final List<MessageDto> messages = new ArrayList<>();

    @Override
    public void displayMsg(final MessageDto msg)
    {
        messages.add(msg);
    }

    // STUB
    public List<MessageDto> getContents()
    {
        return Collections.unmodifiableList(messages);
    }
}