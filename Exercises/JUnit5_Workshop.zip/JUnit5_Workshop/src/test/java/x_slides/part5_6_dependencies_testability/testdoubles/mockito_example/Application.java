package x_slides.part5_6_dependencies_testability.testdoubles.mockito_example;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Application
{
    private final Greeting greeting;
        
    public Application(final Greeting greeting)
    {
        this.greeting = greeting;
    }
    
    public String generateMsg(final String name)
    {
        return greeting.greet(name);
    }
}