package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_FirstTestWithJUnit5
{
    @Test
    void assertMethodsInAction()
    {
        String expected = "Tim";
        String actual = "Tim";
        assertEquals(expected, actual);
        assertEquals(expected, "XYZ", "Message if comaprison fails");

        assertTrue(true);
        assertTrue(true, "Always true");

        assertFalse(false);
        assertNull(null);
        assertNotNull(new Object());
        assertSame(null, null);
        assertNotSame(null, new Object());
    }
}
