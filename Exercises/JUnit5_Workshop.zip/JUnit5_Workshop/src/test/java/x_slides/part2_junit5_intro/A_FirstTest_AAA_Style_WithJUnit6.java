package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_FirstTest_AAA_Style_WithJUnit6
{
    @Test
    void aaa_style_Example()
    {
        // GIVEN: An empty list
        final List<String> names = new ArrayList<>();

        // WHEN: adding 2 elements
        names.add("Tim");
        names.add("Mike");
        
        assertEquals(2, names.size(), "list should contain 2 elements");
    }
}
