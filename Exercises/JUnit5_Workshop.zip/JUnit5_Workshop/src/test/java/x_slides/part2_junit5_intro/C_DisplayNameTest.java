package x_slides.part2_junit5_intro;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class C_DisplayNameTest
{
    @Test
    @DisplayName("(1 * 2 * 3) / 4 = 6/4 = 3/2 = 1.5")
    @Tag("multiplication")
    @Tag("division")
    void divideResultOfMultiplication()
    {
        BigDecimal newValue = BigDecimal.ONE.multiply(BigDecimal.valueOf(2))
                        .multiply(BigDecimal.valueOf(3))
                        .divide(BigDecimal.valueOf(4));

        assertEquals(new BigDecimal("1.5"), newValue);
    }  
}
