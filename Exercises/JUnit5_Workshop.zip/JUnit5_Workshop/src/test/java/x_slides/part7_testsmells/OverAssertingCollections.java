package x_slides.part7_testsmells;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class OverAssertingCollections
{
    @Test
    void overAssertingAndLoosingHelpfulInfo()
    {
        List<String> result = calcResultList();
        
        assertEquals(1, result.size());
        assertEquals("Tom", result.get(0));
    }
    
    private List<String> calcResultList()
    {
        return List.of("Tom", "Jerry");
    }
    
    @Test
    void reasonableAssertProvidingGoodFeedback()
    {
        List<String> result = calcResultList();  
        
        assertEquals(List.of("Tom"), result);
    }
    //
    

}
