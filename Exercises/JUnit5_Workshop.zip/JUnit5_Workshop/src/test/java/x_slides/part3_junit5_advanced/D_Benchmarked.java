package x_slides.part3_junit5_advanced;

import org.junit.jupiter.api.extension.ExtendWith;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@ExtendWith(D_BenchmarkExtension.class)
public @interface D_Benchmarked 
{
}
