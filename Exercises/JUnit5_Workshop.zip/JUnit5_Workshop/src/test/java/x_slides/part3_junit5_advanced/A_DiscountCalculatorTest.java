package x_slides.part3_junit5_advanced;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class A_DiscountCalculatorTest
{
    final A_DiscountCalculator calculator = new A_DiscountCalculator();
    
    @Test
    public void testCalcDiscount_SmallOrder_NoDiscount()
    {
        final int smallAmount = 20;
        assertEquals(0, calculator.calcDiscount(smallAmount), "no discount");
    }

    @Test
    public void testCalcDiscount_MediumOrder_MediumDiscount()
    {
        final int mediumAmount = 200;        
        assertEquals(4, calculator.calcDiscount(mediumAmount), "4 % discount");
    }

    @Test
    public void testCalcDiscount_BigOrder_BigDiscount()
    {
        final int bigAmount = 2000;
        assertEquals(7, calculator.calcDiscount(bigAmount), "7 % discount");
    }
}
