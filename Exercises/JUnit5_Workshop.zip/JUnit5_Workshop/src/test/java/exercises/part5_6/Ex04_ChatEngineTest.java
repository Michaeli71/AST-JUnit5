package exercises.part5_6;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@ExtendWith(MockitoExtension.class)
class Ex04_ChatEngineTest
{
    @Mock
    private MessageSender messageSender;

    @Test
    public void shouldUseMessageSenderToSendMessage()
    {
        final String msg = "SECRET";
        final String expectedAnswer = "SERVICE";

        // ARRANGE
        final Ex04_ChatEngine chatEngine = null; // TODO

        // ACT
        final String response = chatEngine.say(msg);

        // ASSERT
        // TODO
    }
}