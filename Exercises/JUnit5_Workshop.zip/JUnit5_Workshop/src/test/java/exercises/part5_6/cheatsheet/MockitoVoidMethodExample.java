package exercises.part5_6.cheatsheet;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.stubbing.Answer;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoVoidMethodExample
{
    @Test 
    public void testGreetinVoidMethod()
    {
        // Arrange
        final Greeting greeting = Mockito.mock(Greeting.class);
        final Answer<String> answer = (invocation) -> {
            System.out.println("EXECUTING " + invocation.getMethod().getName()
                               + Arrays.toString(invocation.getArguments()));
            return null;
        };
        doAnswer(answer).when(greeting).additional(anyString());
        doThrow(IllegalStateException.class).when(greeting).additional("ERROR");

        // Act
        greeting.additional("Mike");
        assertThrows(IllegalStateException.class,
                     () -> greeting.additional("ERROR"));
    }
}