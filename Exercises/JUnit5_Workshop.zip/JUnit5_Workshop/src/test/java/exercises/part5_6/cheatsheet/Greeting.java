package exercises.part5_6.cheatsheet;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class Greeting
{
    public String greet(final String name)
    {
        return "Hello" + name;
    }

    public void additional(String string)
    {
        
    }
}