package exercises.part5_6;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Comparator;
import java.util.Iterator;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
// Korigere diesen Test
@ExtendWith(MockitoExtension.class)
public class Ex03_MockitoBasicsTest
{
    @Test
    public void iterator_next_return_hello_world()
    {
        // arrange
        Iterator<String> it = Mockito.mock(Iterator.class);
       // TODO

        // act
        String result = it.next() + " " + it.next();

        // assert
        assertEquals("Hello World", result);
    }

    @Test
    public void iterator_hasNext_return_hello_world()
    {
        // arrange
        Iterator<String> it = Mockito.mock(Iterator.class);
        // TODO

        // act
        String result = "";
        while (it.hasNext())
        {
            result += it.next();
        }

        // assert
        assertEquals("HelloCHOPEN", result);
    }

    @Test
    public void with_arguments()
    {
        Comparator<String> comp = Mockito.mock(Comparator.class);
        // TODO
        
        // act
        int result1 = comp.compare("Test", "TEST");
        int result2 = comp.compare("ABC", "DEF");
        
        // assert
        assertAll(() -> assertEquals(1, result1),
                  () -> assertEquals(-1, result2));
    }
}