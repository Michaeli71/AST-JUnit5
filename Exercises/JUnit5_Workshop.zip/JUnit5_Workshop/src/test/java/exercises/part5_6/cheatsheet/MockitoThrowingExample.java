package exercises.part5_6.cheatsheet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
public class MockitoThrowingExample 
{
    @Test
    public void testGreetingReturnValue() {

        // Arrange
        final Greeting greeting = Mockito.mock(Greeting.class);
        // Achtung: Reihenfolge wichtig
        when(greeting.greet(anyString())).
                      thenReturn("Welcome to Mockito");
        when(greeting.greet("Mike")).
                      thenReturn("Mister Mike");
        when(greeting.greet("ERROR")).
                      thenThrow(new IllegalArgumentException());

        // Act
        final Application app = new Application(greeting);
        final String result1 = app.generateMsg("Mike");
        assertEquals("Mister Mike", result1);        
      
        final String result2 = app.generateMsg("ABC");
        assertEquals("Welcome to Mockito", result2);
        
        assertThrows(IllegalArgumentException.class, 
                     () -> greeting.greet("ERROR"));
    }
}