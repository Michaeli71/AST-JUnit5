package exercises.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import org.junit.jupiter.api.Test;

import domain.Person;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex12_CollectionsSortTest
{
    private static final List<Person> persons    = new ArrayList<>(Arrays.asList(new Person("Mike", LocalDate.of(1971, 2, 7), "Bremen"),
                        new Person("Tim", LocalDate.of(1971, 3, 27), "Kiel"),
                        new Person("Peter", LocalDate.of(1999, 12, 15), "Hamburg"),
                        new Person("Tom", LocalDate.of(2011, 11, 11), "Aachen")));

    private final Comparator<Person>  byName     = Comparator.comparing(Person::getName);

    private final Comparator<Person>  byBirthday = Comparator.comparing(Person::getDateOfBirth);

    private final Comparator<Person>  byCity     = Comparator.comparing(Person::getHomeTown);

    @Test
    void testSortedbyName()
    {
        final List<Person> expectedSortedByName = Arrays.asList(new Person("Mike", LocalDate.of(1971, 2, 7), "Bremen"),
                                                          new Person("Peter", LocalDate.of(1999, 12, 15), "Hamburg"),
                                                          new Person("Tim", LocalDate.of(1971, 3, 27), "Kiel"),
                                                          new Person("Tom", LocalDate.of(2011, 11, 11), "Aachen"));
        persons.sort(byName);

        assertEquals(expectedSortedByName, persons);
        assertIterableEquals(expectedSortedByName, persons);
    }

    @Test
    void testSortedbyCity()
    {
        final List<Person> expectedSortedByCity = Arrays.asList(new Person("Tom", LocalDate.of(2011, 11, 11), "Aachen"),
                                                          new Person("Mike", LocalDate.of(1971, 2, 7), "Bremen"),
                                                          new Person("Peter", LocalDate.of(1999, 12, 15), "Hamburg"),
                                                          new Person("Tim", LocalDate.of(1971, 3, 27), "Kiel"));
        persons.sort(byCity);

        assertEquals(expectedSortedByCity, persons);
        assertIterableEquals(expectedSortedByCity, persons);
    }

    @Test
    void testSortedbyBirthday()
    {
        final List<Person> expectedSortedByBirthday = Arrays.asList(new Person("Mike", LocalDate.of(1971, 2, 7), "Bremen"),
                                                              new Person("Tim", LocalDate.of(1971, 3, 27), "Kiel"),
                                                              new Person("Peter", LocalDate.of(1999, 12, 15),
                                                                         "Hamburg"),
                                                              new Person("Tom", LocalDate.of(2011, 11, 11), "Aachen"));
        persons.sort(byBirthday);

        assertEquals(expectedSortedByBirthday, persons);
        assertIterableEquals(expectedSortedByBirthday, persons);
    }
}