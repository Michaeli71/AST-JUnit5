package exercises.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import utils.MathUtils;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class Ex13_PermutationsTest
{
    @Test
    void testCalcPermutationsForA()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("A");

        assertEquals(1, permutations.size());
        assertTrue(permutations.contains("A"));
    }

    @Test
    void testCalcPermutationsForAB()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("AB");

        assertEquals(2, permutations.size());
        assertTrue(permutations.containsAll(Arrays.asList("AB", "BA")));
    }

    @Test
    void testCalcPermutationsForABC()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("ABC");

        assertEquals(6, permutations.size());
        assertTrue(permutations.containsAll(Arrays.asList("ABC", "ACB", "BAC", "BCA", "CBA", "CAB")));
    }

    @Test
    void testCalcPermutationsFor0123456789()
    {
        final String input = "0123456789";
        final int expectedSizeBasedOnFaculty = MathUtils.fac(input.length());

        final Set<String> permutations = Ex13_Permutations.calcPermutations(input);

        assertEquals(expectedSizeBasedOnFaculty, permutations.size());
        // und nun??? wie alle die Werte prüfen?? Ideen
    }

    @Test
    void testCalcPermutationsForAACAA()
    {
        final Set<String> permutations = Ex13_Permutations.calcPermutations("AACAA");

        // UPS: Wie berechnen wir das bei Duplikaten??
        assertEquals(5, permutations.size());
        assertTrue(permutations.containsAll(Arrays.asList("AACAA", "AAAAC", "ACAAA", "AAACA", "CAAAA")));
    }

    private int countDuplicates(final String input)
    {
        int duplicateCount = 0;
        final Set<Character> chars = new HashSet<>();
        for (int i = 0; i < input.length(); i++)
        {
            final char current = input.charAt(i);

            if (chars.contains(current))
            {
                duplicateCount++;
            }
            else
            {
                chars.add(current);
            }
        }
        return duplicateCount > 0 ? duplicateCount + 1 : 0;
    }
    
    // => JUnit 5 

    // TODO
}
