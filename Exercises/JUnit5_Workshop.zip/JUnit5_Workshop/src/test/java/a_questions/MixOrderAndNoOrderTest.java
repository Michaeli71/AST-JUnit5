package a_questions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
@TestMethodOrder(OrderAnnotation.class)
class MixOrderAndNoOrderTest
{
   private static final StringBuilder output = new StringBuilder("");
    
   @Test
   public void testZZZ() {
       output.append("-ZZZ-");
   }

    @Test
    @Order(2)
    public void secondTest() {
        output.append("b");
    }
 
    @Test
    @Order(3)
    public void thirdTest() {
        output.append("c");
    }
 
    @Test
    @Order(4)
    public void firstTest() {
        output.append("a");
    }

    /*
    @Test
    @Order(1)
    public void firstTest2() {
        output.append("first2");
    }
    */
    
    @Test
    public void testXXX() {
        output.append("-xxx-");
    }
    
    @Test
    public void testYYY() {
        output.append("-YYY-");
    }
    
    
    @AfterAll
    public static void assertOutput()
    {
        assertEquals("abc", output.toString());
    }
}
