package a_questions;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm für den Workshop "JUnit 5"
 * 
 * @author Michael Inden
 * 
 * Copyright 2019 by Michael Inden 
 */
class SpecialExceptionTest
{
    // BAD EXAMPLE
    
    @Test
    void testGeneralException()
    {
        assertThrows(IOException.class,
                     () -> { throw new FileNotFoundException("NOT PRESENT"); });
    }
    
    @Test
    void testGeneralException_2()
    {
        assertThrows(IOException.class,
                     () -> { throw new FileAlreadyExistsException("PRESENT"); });
    }
}
