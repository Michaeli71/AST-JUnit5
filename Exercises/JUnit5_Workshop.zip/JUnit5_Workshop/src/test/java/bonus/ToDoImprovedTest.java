package bonus;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.assertj.core.api.AbstractAssert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.AdditionalAnswers;
import org.mockito.Mockito;

public class ToDoImprovedTest {

	private ToDoRepository todoRepository = Mockito.mock(ToDoRepository.class);

	@BeforeEach
	void initUseCase() {
		when(todoRepository.save(Mockito.any(ToDo.class))).then(AdditionalAnswers.returnsFirstArg());
	}

	@Test
	void savedToDoHasCreationDateV1() {
	    ToDo toDo = new ToDo("Solve Exercises");
	
	    ToDo savedToDo = todoRepository.save(toDo);
	
	    assertThat(savedToDo.getCreatedAt()).isNotNull();
	    assertThat(savedToDo.getCompletionStatus()).isEqualTo(ToDo.CompletionStage.OPEN);
	}

    
	@Test
	void savedToDoHasCreationDateV2() {
		ToDo toDo = new ToDo("Solve Exercises");
	
		ToDo savedToDo = todoRepository.save(toDo);
	
		ToDoAssert.assertThat(savedToDo).hasCreationDate();
		ToDoAssert.assertThat(savedToDo).isInOpenState();
		// ToDoAssert.assertThat(savedToDo).hasCreationDate().isInOpenState();
	}
}

class ToDoAssert extends AbstractAssert<ToDoAssert, ToDo> {

	ToDoAssert(ToDo toDo) {
		super(toDo, ToDoAssert.class);
	}

	static ToDoAssert assertThat(ToDo actual) {
		return new ToDoAssert(actual);
	}

	public ToDoAssert hasCreationDate() {
		isNotNull();
		if (actual.getCreatedAt() == null) {
			failWithMessage("Expected ToDo to have a creation date, but it was null");
		}
		return this;
	}
	
	public ToDoAssert isInOpenState() {
		isNotNull();
		if (actual.getCompletionStatus() != ToDo.CompletionStage.OPEN) {
			failWithMessage("Expected ToDo to have a completion state of OPEN, but was " + actual.getCompletionStatus());
		}
		return this;
	}
}
